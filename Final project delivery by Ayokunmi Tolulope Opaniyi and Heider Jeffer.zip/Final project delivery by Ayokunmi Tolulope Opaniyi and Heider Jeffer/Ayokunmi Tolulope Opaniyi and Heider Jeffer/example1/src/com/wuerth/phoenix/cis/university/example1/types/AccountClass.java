package com.wuerth.phoenix.cis.university.example1.types;

public enum AccountClass {

	SalesReporting,
	PLStatement,
	AllocationFormula,
	BalanceSheet,
	Logistics
}
