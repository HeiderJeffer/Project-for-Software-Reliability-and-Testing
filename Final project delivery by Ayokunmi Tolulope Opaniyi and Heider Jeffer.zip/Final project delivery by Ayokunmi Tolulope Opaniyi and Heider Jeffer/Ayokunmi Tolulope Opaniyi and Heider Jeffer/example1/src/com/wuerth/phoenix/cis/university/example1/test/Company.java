package com.wuerth.phoenix.cis.university.example1.test;

import com.wuerth.phoenix.cis.university.example1.adapters.ICompany;

public class Company implements ICompany {

}
