package com.wuerth.phoenix.cis.university.example1.types;

public enum DataScenarioType {

	Actual,
	Deferral,
	Extrapolation,
	Target,
	Plan,
}
