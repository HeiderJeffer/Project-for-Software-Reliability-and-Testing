package com.wuerth.phoenix.cis.university.example1.adapters;

public interface ICompany {

}
