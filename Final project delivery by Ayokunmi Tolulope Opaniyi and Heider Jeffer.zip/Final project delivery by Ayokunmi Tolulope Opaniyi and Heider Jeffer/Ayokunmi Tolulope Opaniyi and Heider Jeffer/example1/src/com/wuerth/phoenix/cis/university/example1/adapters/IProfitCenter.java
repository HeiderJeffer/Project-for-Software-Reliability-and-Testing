package com.wuerth.phoenix.cis.university.example1.adapters;

public interface IProfitCenter {

	public String getName();
	public boolean isNotAllocated();
}
