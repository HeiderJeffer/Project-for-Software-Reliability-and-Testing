package com.wuerth.phoenix.cis.university.example1.types;

public enum DataType {

	SalesReporting,
	PLStatement,
	AllocationFormula,
	BalanceSheet,
	Logistics,
	Acquisition,
}
