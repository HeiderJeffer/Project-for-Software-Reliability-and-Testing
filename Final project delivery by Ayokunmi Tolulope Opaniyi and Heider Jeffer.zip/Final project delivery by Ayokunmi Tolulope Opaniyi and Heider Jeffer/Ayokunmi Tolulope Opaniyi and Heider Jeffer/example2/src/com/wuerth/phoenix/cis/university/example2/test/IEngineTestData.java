// IEngineTestData by Heider and Ayo
package com.wuerth.phoenix.cis.university.example2.test;

import com.wuerth.phoenix.cis.university.example2.util.Scenario;

public interface IEngineTestData {

	public boolean start();
	
	public boolean check(Scenario scenario);
}
