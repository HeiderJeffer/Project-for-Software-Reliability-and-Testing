package com.wuerth.phoenix.cis.university.example2.util;

import java.util.ArrayList;

/**
 * Adapter for an Import File
 */
public class Combination {

	private ArrayList<CombinationLine> lineList = new ArrayList<>();
	

	public ArrayList<CombinationLine> getLineList() {
		return lineList;
	}
}
