package com.wuerth.phoenix.cis.university.example2.test.ayo;

public class ATransactionOperation<T> {

}
